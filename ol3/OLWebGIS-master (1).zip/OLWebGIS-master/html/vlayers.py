#!/usr/bin/python

print "Content-type: text/html\n\n";

import sys
sys.path.append("../msconfig")

import CGIUtils

MAPFILE = '../msconfig/vlayers.map'

#MAPSERV = '../cgi-bin/mapserv-5.6.5.exe'
MAPSERV = '../cgi-bin/mapserv-pre-6.2-70d2510636.exe'

CGIUtils.mapserv_inject_mapfile(MAPFILE, MAPSERV)
