Seldon
=======

Foundation for OpenLayers GIS viewer.
