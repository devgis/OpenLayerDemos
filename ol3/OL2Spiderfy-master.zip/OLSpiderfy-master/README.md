OLSpiderfy
==========

A Spiderfy control for clusters in OpenLayers

Under development.

[![](https://raw.github.com/alrocar/OLSpiderfy/master/ol_spiderfy.gif)](http://github.com/alrocar/OLSpiderfy)

