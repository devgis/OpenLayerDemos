# OL3-AnimatedCluster
A cluster layer for OpenLayers 3 (OL3)  that animates clusters on zoom change and a select interaction that spread out cluster to allow feature selection  in it.

Inspired by [acanimal/AnimatedCluster](https://github.com/acanimal/AnimatedCluster).

[View the live  example...](http://viglino.github.io/OL3-AnimatedCluster)
