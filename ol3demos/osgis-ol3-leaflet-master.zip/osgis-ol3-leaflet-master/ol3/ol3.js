var map = new ol.Map({
    target: 'map',
    layers: [

    ],
    view: new ol.View({

    })
});
